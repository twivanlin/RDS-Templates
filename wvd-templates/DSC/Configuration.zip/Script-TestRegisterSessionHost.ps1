﻿<#

.SYNOPSIS
Test if Session Host was registered to the Host Pool.

.DESCRIPTION
The supported Operating Systems Windows Server 2016.

.ROLE
Readers

#>
param(
    [Parameter(mandatory = $false)]
    [string]$RDPSModSource = 'attached'
)

$ScriptPath = [System.IO.Path]::GetDirectoryName($PSCommandPath)

# Dot sourcing Functions.ps1 file
. (Join-Path $ScriptPath "Functions.ps1")

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

write-log -message 'Script being executed: Test if Session Host is registered to the Host Pool'

Write-Log -Message "Check if RD Infra registry exists"


# Testing if it is a ServicePrincipal and validade that AadTenant ID in this case is not null or empty
#ValidateServicePrincipal -IsServicePrincipal $isServicePrincipal -AADTenantId $AadTenantId

ImportRDPSMod -Source $RDPSModSource -ArtifactsPath $ScriptPath

# Authenticating to Windows Virtual Desktop
#. AuthenticateRdsAccount -DeploymentUrl $RDBrokerURL -Credential $TenantAdminCredentials -ServicePrincipal:($isServicePrincipal -eq 'True') -TenantId $AadTenantId

#SetTenantGroupContextAndValidate -TenantGroupName $definedTenantGroupName -TenantName $TenantName

# Getting fqdn of rdsh vm
$SessionHostName = GetCurrSessionHostName
Write-Log -Message "Fully qualified domain name of RDSH VM: $SessionHostName"

#$SessionHost = Get-RdsSessionHost -TenantName "$TenantName" -HostPoolName "$HostPoolName" -Name "$SessionHostName" -ErrorAction SilentlyContinue
Write-Log -Message "Check if SessionHost '$SessionHostName' is registered to Host Pool '$HostPoolName' in Tenant '$TenantName'"

Write-Log -Message "SessionHost '$SessionHostName' is registered. $($SessionHost | Out-String)"

return $true